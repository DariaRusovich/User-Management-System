export default class LocalStorageUtil {
  constructor() {}
  setToken() {
          
  }
}
