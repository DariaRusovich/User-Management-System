export const BASE_URL = 'http://localhost:3000/api/v1';
export const DEPARTMENTS_URL = '/departments';
export const DEPARTMENT_BY_ID_URL = `/departments/`;
export const LOGIN = '/login';
export const EMPLOYEES_URL = '/employees';
