import React, { Component } from 'react';
import DepartmentsList from '../components/DepartmentsList';

export default class HomePage extends Component {
  render() {
    return (
      <>
        <DepartmentsList />
      </>
    );
  }
}
