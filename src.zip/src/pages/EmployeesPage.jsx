import React, { Component } from 'react';
import EmployeesList from '../components/EmployeesList';

export default class EmployeesPage extends Component {
  render() {
    return (
      <>
        <EmployeesList />
      </>
    );
  }
}
