import React, { Component } from 'react';
import NotFound from '../components/NotFound';

export default class LoginPage extends Component {
  render() {
    return (
      <>
        <NotFound />
      </>
    );
  }
}
