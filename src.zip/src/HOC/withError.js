import React, { Component } from 'react';
import Error from '../components/Error';

const withError = (OriginalComponent) => {
  class NewComponent extends Component {
    state = {
      error: null,
    };
    handleError = () => {
        this.setState((prev) => ({ ...prev, error: <Error /> }))
    }
    render() {
      const { error } = this.state;
      return (
        <div>
          {error && <Error />}
          <OriginalComponent handleError={this.handleError} {...this.props} />
        </div>
      );
    }
  }
  return NewComponent;
};

export default withError;
