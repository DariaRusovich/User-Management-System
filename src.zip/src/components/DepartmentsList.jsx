import React, { Component } from 'react';
import { getDepartments } from '../api/api';
import withError from '../HOC/withError';
import withLoader from '../HOC/withLoader';
import Department from './Department';

class DepartmentsList extends Component {
  state = {
    departments: [],
  };

  async componentDidMount() {
    this.props.handleToggleLoader();
    const [departmentsError, departments] = await getDepartments();
    if (!departmentsError) {
      this.setState({ departments: departments.departments });
    } else {
      this.setState({ error: departmentsError });
      this.props.handleError();
    }
    this.props.handleToggleLoader();
  }

  render() {
    const { departments } = this.state;
    return (
      <section className="section">
        <div className="container section-wrap">
          {departments &&
            departments.map((department) => (
              <Department
                key={department.id}
                department={department}
              ></Department>
            ))}
        </div>
      </section>
    );
  }
}

export default withError(withLoader(DepartmentsList));
